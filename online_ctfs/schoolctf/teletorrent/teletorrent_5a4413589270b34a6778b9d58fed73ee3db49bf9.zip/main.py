import sys
import wave
import zlib
import string

def read_wave(fname):
	w = wave.open('waves/'+fname, 'rb')
	frame = w.readframes(w.getnframes())
	w.close()
	return frame
	
class EsKakDollar:		
	def __init__(self):
		self.waves = {}
		# Lowecase letters an digits as is
		for c in string.lowercase + string.digits:
			infile = "%s.wav" % c
			self.waves[c] = [read_wave(infile)]
		# Add postfix to uppercase letters
		bolsh = read_wave('cap.wav')
		for c in string.lowercase:
			self.waves[c.upper()] = self.waves[c] + [bolsh]
		# Some additional characters
		self.waves['/'] = [read_wave('sleh.wav')]
		self.waves['+'] = [read_wave('+.wav')]
		self.waves['='] = [read_wave('=.wav')]
	
	def encode(self, outfile, text):
		output = wave.open(outfile, 'wb')
		w = wave.open('waves/a.wav', 'rb')
		params = w.getparams()
		w.close()
		output.setparams(params)
		
		try:
			for c in text:
				for frame in self.waves[c]:
					output.writeframes(frame)
		except:
			raise Exception("Not implemented character '%s'" % c)
		output.close

if __name__ == "__main__":
	if len(sys.argv) != 3:
		print "Usage: %s <outfile> <Text to speech>" % sys.argv[0]
		exit(1)
	text_to_speech = zlib.compress(sys.argv[2]).encode('base64').replace('\n','')
	es = EsKakDollar()
	es.encode(sys.argv[1], text_to_speech)