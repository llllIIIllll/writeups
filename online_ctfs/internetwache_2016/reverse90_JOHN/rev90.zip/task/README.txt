Scrambling:
F' D' U' L' U' F2 B2 D2 F' U D2 B' U' B2 R2 D2 B' R' U B2 L U R' U' L'


White side:
-------
|I|3| |
| |D|R|
| | | |
-------

Orange side:
-------
|C| | |
| | | |
| | | |
-------

Yellow side:
-------
|{| | |
|3| | |
| | |}|
-------


Red side:
-------
| | | |
|W| | |
| | | |
-------

Green side:
-------
| | | |
| | | |
| | | |
-------

Blue side:
-------
| | | |
| | | |
| | | |
-------
