Minetest Game mod: tnt
======================
by PilzAdam and ShadowNinja

Introduction:
This mod adds TNT to Minetest. TNT is a tool to help the player
in mining.

How to use the mod:
Craft gunpowder by placing coal and gravel in the crafting area. The
gunpowder can be used to craft TNT or as fuze for TNT. To craft TNT
surround gunpowder with 4 wood in a + shape.
There are different ways to blow up TNT:
  1. Hit it with a torch.
  2. Hit a gunpowder fuze that leads to a TNT block with a torch.
  3. Activate it with mesecons (fastest way)
Be aware of the damage radius of 7 blocks!

License:
WTFPL (see below)

See also:
http://minetest.net/

         DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
                    Version 2, December 2004

 Copyright (C) 2004 Sam Hocevar <sam@hocevar.net>

 Everyone is permitted to copy and distribute verbatim or modified
 copies of this license document, and changing it is allowed as long
 as the name is changed.

            DO WHAT THE FUCK YOU WANT TO PUBLIC LICENSE
   TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION

  0. You just DO WHAT THE FUCK YOU WANT TO.
