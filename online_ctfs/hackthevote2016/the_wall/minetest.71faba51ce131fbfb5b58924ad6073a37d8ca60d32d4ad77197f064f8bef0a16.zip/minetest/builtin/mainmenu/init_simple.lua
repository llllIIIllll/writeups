-- helper file to be able to debug the simple menu on PC
-- without messing around with actual menu code!
PLATFORM = "Android"
dofile("builtin/mainmenu/init.lua")
